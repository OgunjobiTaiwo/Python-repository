3.5
print("Enter any 2 integers of your choice: ")
number1=int(input("Enter first integer: "))
number2=int(input("Enter second integer: "))

if number1==number2:
	print(number1, "is equal to", number2)
elif number1 != number2:
	print(number1, 'is not equal to', number2)
elif number1 < number2:
	print(number1, 'is less than', number2)
elif number1 > number2:
	print(number1, 'is greater than', number2)
elif number1 <= number2:
	print(number1, 'is less than or equal to', number2)
elif number1 >= number2:
	print(number1, 'is greater than or equal to', number2)




