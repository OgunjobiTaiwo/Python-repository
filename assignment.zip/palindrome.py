number = int(input("Enter any 5 digit integer"))
original=number
separated_digit = 0
reverse = 0
for digit in range(5):
	separated_digit = number%10
	reverse = reverse * 10 + separated_digit
	number=number//10
if original== reverse:
	print("Palindrome")
else:
	print("Not a palindrome")	