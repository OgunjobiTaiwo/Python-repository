

principal = 1000 
rate = 0.07

for years in range(0,32,10):
	amount =int( principal*(1+rate)**years)
	amount = amount+principal

	print(years ," " , amount)



