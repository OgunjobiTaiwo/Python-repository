Number1 = float(input('Enter a decimal number: '))
Number2 = float(input('Enter a decimal number: '))
Number3 = float(input('Enter a decimal number: '))

 if Number1 < Number2 or Number2 < Number3:
 	print( Number1, Number2 , Number3)

 elif Number2 < Number1 or Number1 < Number3:
  	print( Number2 , Number1 , Number3)

 else:
 	print(Number3 , Number2 , Number1)
