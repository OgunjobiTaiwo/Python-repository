First_number = 1
Second_number = 2
Third_number = 3
Fourth_number = 4
Fifth_number = 5

square_1 = (First_number * 2)
square_2 = (Second_number * 2)
square_3 = (Third_number * 2)
square_4 = (Fourth_number *2)
square_5 = (Fifth_number * 2)


cube_1 = (First_number * 3)
cube_2 = (Second_number * 3)
cube_3 = (Third_number * 3)
cube_4 = (Fourth_number * 3)
cube_5 = (Fifth_number * 3)


print(“Number\tSquare\tcube”)
print(First_number, “\t”, square_1, “\t” , cube_1)
print(First_number, “\t”, square_2, “\t” , cube_2)
print(First_number, “\t”, square_3, “\t” , cube_3)
print(First_number, “\t”, square_4, “\t” , cube_4)
print(First_number, “\t” ,square_5, “\t” , cube_5)


print(“Number\tSquare\tcube”)
print( “\t” ,First_number, “\t”, square_1, “\t” , cube_1)
print( “\t” ,First_number, “\t” ,square_2, “\t” , cube_2)
print( “\t” ,First_number, “\t”, square_3, “\t” , cube_3)
print( “\t” ,First_number, “\t”, square_4, “\t” , cube_4)
print(“\t”First_number, “\t”, square_5, “\t” , cube_5)
