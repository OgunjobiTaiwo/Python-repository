3.6
question = input("What is your problem?")
answer=input("Have you had this problem before(yes or no)? ")

if answer == "yes":
	print(f"you have {answer} again")
else:
	print("well you have it now")