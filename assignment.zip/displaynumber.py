Number_1 = int(input('Enter your first  number: '))
Number_2 = int(input('Enter your second number: '))
Number_3 = int(input('Enter your third number: '))

sum = Number_1 + Number_2 + Number_3
print(sum)

average =( Number_1 + Number_2 + Number_3 ) / 3
print(average)

product = Number_1 * Number_2 * Number_3
print(product)

if ( Number_1 < Number_2 and Number_3)
print('Smallest number is ' Number_1)

if (Number_2 < Number_1 and Number_3)
print('Smallest number is 'Number_2)

if (Number_3 < Number_2 and Number_1)
print('Smallest number is ' Number_3)

if ( Number_1 > Number_2 and Number_3)
print('Largest number is ' Number_1)

if (Number_2 > Number_1 and Number_3)
print('Largest number is ' Number_2)

if (Number_3 > Number_2 and Number_1)
print('Largest number is ' Number_3)
