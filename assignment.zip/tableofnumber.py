for number in range(0,6):
	square = number*number
	cube = number*number*number
	print(f"{number}\t{square} \t{cube}\n")