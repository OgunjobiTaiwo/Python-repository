number1=int(input("Enter your first number: "))
number2=int(input("Enter your second number: "))
number3=int(input("Enter your third number: "))
number4=int(input("Enter your fourth number: "))

smallest= number1
largest=number1
count=0
sum=0
product=1
for number in range(number1,number2,number3,number4):
	
	sum = sum+number
	product=product*number
	
	if number < smallest:
		smallest = number
	if number1 > largest:
		largest = number
	count+= 1

average=sum/count
print(sum, "Sum")
print(product, "Product")
print(average, "Average")
print(largest, "Largest")
print(smallest, "Smallest")