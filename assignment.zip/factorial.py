
number = int(input(" Enter a  number : "))
count =1

factorial = 1

while count<= number:
	factorial =factorial * count
	count+=1

print("Factorial", factorial)