Principal_amount = 1000
duration1 = 10
duration2 = 20
duration3 = 30

amount_1 = 1000(1 + 7)10
amount_2 = amount_1(1 + 7)20
amount_3 = amount_2(1 + 7)30

total = amount_1 + amount_2 + amount_3

print("The amount after the 10th year is" ,"$",amount_1)
print("The amount after the 20th year is", "$",amount_2)
print("The amount after the 30th year is", "$",amount_3)
print(total)
