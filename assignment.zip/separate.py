number = int(input("Enter any 5 digit integer"))
separated_digit = 0
for digit in range(5):
	separated_digit = number // 10000
	print(separated_digit)	
	
	number=number%10000
	number = number * 10 
	
