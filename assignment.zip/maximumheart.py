age = int(input(‘Enter your age in years: ’))

maximum_heartrate  = 200 - age
print(‘Your Maximum heart rate is’, maximum_heartrate )
