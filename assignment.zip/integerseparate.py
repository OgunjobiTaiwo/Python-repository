Number1 = int(input('Enter your first  number: '))
Number2 = int(input('Enter your second number: '))
Number3 = int(input('Enter your third number: '))
Number4 = int(input('Enter your fourth  number: '))
Number5 = int(input('Enter your fifth number: '))

print(Number1,Number2,Number3,Number4,Number5)

print(Number1 % 10000)
print(Number2 % 1000)
print(Number3 % 100)
print(Number4 % 10)
print(Number5)
